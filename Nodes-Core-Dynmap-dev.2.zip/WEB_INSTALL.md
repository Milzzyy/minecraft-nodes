# Nodes core Dynmap installer — core-dev.2

This update embeds the supplied fork's compiled Nodes editor/viewer web assets in the existing Nodes plugin. It adds an install-command workflow comparable to the setup described on Burlan Territories' Modrinth page (https://modrinth.com/plugin/burlant/). No BurlanTerritories code is copied. No separate plugin is required for this feature.

## Installation

Use a staging server with Java 21, Paper 1.21.11, the existing Nodes dependencies and an installed/configured Dynmap. Replace the existing Nodes core JAR with the included core-dev.2 JAR; keep only one Nodes JAR. Existing experimental core-dev.1 features and their documented limitations remain.

Add this section to your existing plugins/nodes/config.yml, then restart:

```yaml
nodesWeb:
  webRoot: plugins/dynmap/web
  publicUrl: 'https://your-map.example.com'
```

Set webRoot to the actual Dynmap web directory, including a custom/external web-server directory if applicable. It must already contain js/map.js and standalone/config.js. The configured publicUrl is the Dynmap base URL, including any subpath. Do not append nodes.html.

Run with nodes.admin permission:

```text
/nda dynmap install
/nda save sync
/nda dynmap export
/nda dynmap status
/nda dynmap links
```

The long alias /nodesadmin dynmap works too. The existing native tab completer does not yet suggest these new subcommands; type them explicitly.

## Commands

| Command | Behavior |
| --- | --- |
| `/nda dynmap install` | Install 362 bundled editor/viewer assets. Back up overwritten files under plugins/nodes/web-backups/install-... before replacement. Preserve Dynmap index.html, configuration, tiles and unrelated files. |
| `/nda dynmap export` | Copy existing Nodes world.json, towns.json, config.json, and optional ports.json/nameoverrides.json into the Dynmap nodes directory. Back up replaced JSON first. Does not publish config.yml, SQL passwords or core state. |
| `/nda dynmap status` | Report missing/modified bundled files and required data-file presence. This is a filesystem check, not a browser/network test. |
| `/nda dynmap links` | Print viewer and editor URLs using publicUrl. |

Pages are `<Dynmap URL>/nodes.html` and `<Dynmap URL>/editor.html`. Installation is repeatable; it restores bundled assets and backs up any customised versions before replacement. Keep your customisations in a separate copy if needed. Export copies the latest on-disk JSON; it does not force generation of missing native files. If config.json/world.json/towns.json is missing, initialise/save the native Nodes world/export first.

The existing native Dynmap-copy mechanisms still control subsequent automatic updates. For a custom web root, configure the native/core Dynmap paths to that same directory or run export manually after saves. The installer does not silently rewrite your existing export settings.

## Editing and applying changes

Use the fork's existing browser editor to edit and download/export world JSON. This update adds no browser-to-server write endpoint and no automatic import. Review the downloaded JSON, back up server data, then upload it through your normal server file access. Changes to existing territories can use the native territory reload commands; changes introducing new territory IDs/topology should be applied with the server stopped and loaded on restart.

The editor URL is a static page, not an authenticated admin session. Anyone allowed by your web server to load the page can use its local editing UI and see the same published map data; they cannot save back to the Minecraft server through this installer. Apply web-server authentication if you want the editor page private. A Minecraft permission alone does not protect a static web URL.

## Recovery

Backups mirror the overwritten paths under the dated backup directory. To restore, stop activity on the web files and copy the desired backup files back into webRoot. Newly installed files have no previous copy; remove only those you intend to undo. The deploy method attempts rollback for ordinary I/O errors. A process crash/power loss during the multi-file commit can leave a mixed asset set; rerun install or restore the backup. Per-file replacements use atomic moves and reject symbolic links and directory traversal.

## Validation and limits

- Java 21 compilation succeeds against the bundled 1.21.11 API.
- Existing bytecode assembly/dataflow checks pass and preserve the original Nodes main class/name.
- Six filesystem checks pass: installation, backup content, preserving Dynmap index, nested assets, traversal rejection and symbolic-link rejection.
- Editor/viewer JS, WASM, CSS and icons are reused from the user-provided MainNodes archive; they were not rebuilt from Rust/React source in this update.
- No running Minecraft/Dynmap browser integration test was performed. The templates reference the fork's existing Dynmap 3.3.2-era frontend assets; newer or customised Dynmap deployments may require template adjustments.
- This is a development candidate. It does not resolve the earlier core feature coverage gaps.

## Rebuild

The included nodes-core-upgrade directory contains the updated Java source, bundled nodes-web.zip resource and original core assembly inputs. Set JAVA_HOME to JDK 21 and run python3 rebuild.py from that directory. The updated output filename is nodes-1.21.11-core-dev.2.jar. Tests/WebInstallerTest.java contains the standalone filesystem test harness.
