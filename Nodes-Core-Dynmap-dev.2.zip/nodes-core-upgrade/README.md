# Nodes 1.21.11 integrated core candidate

Read CORE_MIGRATION.md and config-coverage.csv before deployment. This is core-dev.1 and remains experimental; it does not implement every reference feature.

## Install for testing

Back up the entire server and plugins/nodes folder. Stop the server. Replace the existing Nodes JAR with the core candidate; keep only one Nodes JAR. Use Java 21 and Paper 1.21.11. Install the original required dependencies (PacketEvents, Vault, Kotlin runtime and an economy provider for money operations). Preserve the original resource/world files. Merge the supplied config into plugins/nodes/config.yml manually; an existing config is not automatically upgraded on disk. Start a staging copy and review logs before use. Folia is not supported by these new modules.

Core state is in plugins/nodes/core/state.yml with an atomic replacement and backup. Back it up together with the original world/state files. Pending external money transfers require staff reconciliation; never replay them automatically.

## Commands

Existing command permissions still apply. Mutations also check town/nation leadership; staff commands require nodes.admin.

- /nation vassal offer <nation> [resourcePercent] [economyPercent]
- /nation tributary offer <nation> [resourcePercent] [economyPercent]
- /nation vassal|tributary accept|decline|release|break <nation>
- /nation subjects
- /nation tax resources|economy <percent>
- /town bank|deposit|withdraw [amount] and /nation bank|deposit|withdraw [amount]
- /town plotbank <plot> [deposit|withdraw <amount>]
- /town levy <amount>; /town bills; /town bills pay <id>
- /town plotupkeep <plot> <amount>
- /town pvp; /town sphere; /town waypoint; /town rp <message>
- /war <town-or-nation> and /war join <id> attackers|defenders (new war mode only)
- /peace surrender <target> [conquer|plunder] (requires newStyleSurrenderConquer)
- /nda core region <nation> <minX> <minZ> <maxX> <maxZ>
- /nda core audit; /nda core resolve <payment-id> applied|not-applied
- /nda core inactive; /nda core relay <message>

Offers are in memory and expire after 10 minutes. Vassal breaking declares war; tributary breaking is peaceful. Both can carry negotiated tribute. Resources go to the recipient's native town income inventory; money goes to the separate treasury ledger. Default creation/claim fees and upkeep are zero to avoid introducing new charges to an existing server.

## Rebuild

Run `python3 rebuild.py` with a JDK 21 JAVA_HOME (or java and javac on PATH). The included API/ASM/JDBC jars support an offline rebuild of the Java additions and bytecode assembly. Output: dist/nodes-1.21.11-core-dev.1.jar. Dependencies retain their embedded notices; they are not all server plugins.

The package includes the fork's Kotlin source with initial lifecycle/config hooks, the new Java core source, tests and the assembler. The supported candidate build uses the supplied packaging/base-nodes.jar and applies integration hooks directly to its classes. This avoids needing the fork's unavailable original build environment. A plain Gradle build of the Kotlin tree does NOT provide every assembler hook; use rebuild.py for this candidate. It is not a fully source-recompiled replacement of the fork.

For model/assembly tests using Maven 3.9+ and Java 21: `mvn test`. This may download dependencies on the first run. The packaged JAR retains the original plugin name/main class. Do not install the Maven module's thin JAR as a standalone plugin.
