# MainNodes core upgrade: comparison and coverage

This is an **experimental development candidate**, not completion of every feature requested. It extends the supplied Nodes binary inside the existing `nodes` plugin, with the original `phonon.nodes.NodesPlugin` lifecycle. No separate governance addon is installed. The earlier bounty addon remains separate and is not bundled.

## Inputs and config comparison

Compared the supplied MainNodes `config.yml` with `uhh(1).yml`. Found **179 missing leaf settings** and **38 shared leaf settings with different values**. Shared differences are balance/configuration choices; MainNodes values are preserved. Every reference leaf is present in the merged configuration. Presence alone does not establish implemented behavior.

The accompanying CSV lists every missing leaf, its implementation status and both values. Classification is based on code-path review, not live server testing.

| Status | Settings |
| --- | ---: |
| IMPLEMENTED / UNVERIFIED | 125 |
| NATIVE ALIAS | 11 |
| PARTIAL | 13 |
| NOT IMPLEMENTED | 14 |
| INTERPRETED | 12 |
| EXPERIMENTAL | 4 |

## Core behavior added

- Negotiated nation vassal/tributary agreements, acceptance/release/break, cycle prevention, UUID persistence, tax terms, vassal war restrictions and inherited enemies.
- Resource taxation hooks into native town income; tribute reaches the recipient town's original income inventory. Fractional carries and distance penalties are included.
- Optional Vault town/nation/plot treasuries, deposits/withdrawals, resource/economy tax controls, resident levy invoices, recurring plot invoices and upkeep. These treasuries are separate from the ore income GUI.
- Optional war warmup, participants, expiry, surrender, conquest/plunder records and sphere claim markers. These are newly inferred rules, not recovered implementations from the unknown reference fork.
- Town rename/nation rejoin cooldowns, claim/action restrictions, PvP/mob rules, world/map/region bounds, ore/crop toggles, chat/hover/local RP, sidebar text, configurable Dynmap paths and optional audit/relay code.

## Remaining gaps

- JourneyMap client waypoint delivery needs the actual JMWaypointManager API/source; current implementation only points a vanilla compass at home and reports coordinates.
- Tab section refresh schedules, legacy staff permission styling and player ping toggles are not implemented. Headers/footers and mapped column labels work through the current renderer paths.
- UnlimitedNametags is approximated with native text displays. Skull GUI switch has no identified matching call sites in the supplied binary.
- Exact reference-fork war, sphere, territorial-distance, inactivity-removal, XC damage and third-party colony integration behavior is not established. SQL is audit logging, not a database-backed replacement for world/state storage.
- Defense relay cannot recover a defender identity from the original cancellation event; it says unknown defender. Separate success-defense template is not wired.

## Validation

- Java 21 compilation against Spigot API 1.21.11 succeeds.
- 9 automated tests pass: 8 model tests and one assembly test. They cover duration/amount parsing, relationship cycles/tree membership/expiry, tax calculations and plugin identity/bytecode structure.
- ASM dataflow checks pass for the modified original classes. The assembly verifies required lifecycle, income, membership, minimap, chat, nametag and world/interaction hook sites.
- The standalone Python rebuild succeeds using the included dependency jars and JDK 21.
- A full JVM linkage probe was blocked by the absence of the original mandatory Vault API dependency in the supplied runtime files. This is **not** a successful plugin startup test.
- No live Paper server, multiplayer combat, Vault transfer/crash simulation, MySQL, Discord delivery or JourneyMap integration was exercised. Use a backed-up staging server first.

## Configuration choices

MainNodes values stay intact. Selected newly introduced defaults preserve its existing behavior: old war mode, original ore/crop generation, original distances/tick intervals, no extra creation/claim/upkeep charges, no text-display nametags, and no flagged-chunk permission bypass. The CSV shows actual merged values. `coreSafety.deleteInsolventTowns` defaults false. Restart after config changes; no full module reload command is provided.

To finish an exact port, supply the source (or at least the JAR plus version/API documentation) of the fork that produced `uhh.yml`.
