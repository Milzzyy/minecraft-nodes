#!/usr/bin/env python3
"""Rebuild the supplied core candidate using Python 3 and JDK 21+. No server is started."""
import os, pathlib, shutil, subprocess
root=pathlib.Path(__file__).resolve().parent
os.chdir(root)
def tool(name):
    home=os.environ.get('JAVA_HOME')
    p=pathlib.Path(home,'bin',name+('.exe' if os.name=='nt' else '')) if home else None
    return str(p) if p and p.is_file() else shutil.which(name) or name
classes=root/'target/classes'; pack=root/'target/packager';classes.mkdir(parents=True,exist_ok=True);pack.mkdir(parents=True,exist_ok=True)
cp=str(root/'deps/*')
sources=[str(p) for p in (root/'MainNodes/nodes/src/main/java').rglob('*.java')]
subprocess.run([tool('javac'),'--release','21','-encoding','UTF-8','-cp',cp,'-d',str(classes),*sources],check=True)
subprocess.run([tool('javac'),'--release','21','-cp',cp,'-d',str(pack),str(root/'tests/src/test/java/phonon/nodes/core/CoreAssembler.java')],check=True)
out=root/'dist/nodes-1.21.11-core-dev.2.jar'
subprocess.run([tool('java'),'-Xverify:all','-cp',os.pathsep.join([cp,str(classes),str(pack)]),'phonon.nodes.core.CoreAssembler',str(root/'packaging/base-nodes.jar'),str(classes),str(root/'MainNodes/nodes/src/main/resources'),str(out),str(root/'deps/mysql-connector-j-9.2.0.jar'),str(root/'deps/protobuf-java-4.29.0.jar')],check=True)
print(out)
