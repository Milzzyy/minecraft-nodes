package phonon.nodes.serdes

public interface TownRecord : SaveState {
    public val name: String
}
