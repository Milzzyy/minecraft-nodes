package phonon.nodes.core;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;
import java.nio.file.*;
import java.io.*;
import java.util.*;
import java.util.zip.*;

/** Core-owned deployment of the fork's bundled editor/viewer. No HTTP write endpoint. */
public final class DynmapInstaller {
 final JavaPlugin plugin;
 public DynmapInstaller(JavaPlugin plugin){this.plugin=plugin;}
 Path root(){String raw=plugin.getConfig().getString("nodesWeb.webRoot","plugins/dynmap/web");Path p=Path.of(raw).toAbsolutePath().normalize();if(!Files.isDirectory(p)||!Files.isRegularFile(p.resolve("js/map.js"))||!Files.isRegularFile(p.resolve("standalone/config.js")))throw new IllegalArgumentException("Not an installed Dynmap web root: "+p+". Set nodesWeb.webRoot and restart.");return p;}
 Map<String,byte[]> bundle()throws IOException{Map<String,byte[]> files=new LinkedHashMap<>();try(InputStream raw=plugin.getResource("nodes-web.zip")){if(raw==null)throw new IOException("Missing bundled web assets");try(var zip=new ZipInputStream(raw)){ZipEntry e;while((e=zip.getNextEntry())!=null)if(!e.isDirectory())files.put(e.getName(),zip.readAllBytes());}}return files;}
 static Path safe(Path root,String relative)throws IOException{Path p=root.resolve(relative).normalize();if(!p.startsWith(root)||p.equals(root))throw new IOException("Invalid asset path");for(Path at=p;at!=null&&at.startsWith(root);at=at.getParent())if(Files.isSymbolicLink(at))throw new IOException("Symbolic link refused: "+at);return p;}
 /** Stage every byte and back up overwritten targets before the first public mutation. */
 public static void deploy(Path root,Path backup,Map<String,byte[]> files)throws IOException{
  root=root.toAbsolutePath().normalize();backup=backup.toAbsolutePath().normalize();Files.createDirectories(backup);Map<Path,Path> staged=new LinkedHashMap<>();Set<Path> existed=new HashSet<>();List<Path> changed=new ArrayList<>();
  try{for(var entry:files.entrySet()){Path dest=safe(root,entry.getKey());if(Files.exists(dest)&&!Files.isRegularFile(dest))throw new IOException("Target is not a regular file: "+dest);Path save=backup.resolve(entry.getKey());if(Files.exists(dest)){Files.createDirectories(save.getParent());Files.copy(dest,save,StandardCopyOption.COPY_ATTRIBUTES);existed.add(dest);}Files.createDirectories(dest.getParent());Path temp=Files.createTempFile(dest.getParent(),".nodes-install-",".tmp");staged.put(dest,temp);Files.write(temp,entry.getValue());}
   for(var e:staged.entrySet()){Files.move(e.getValue(),e.getKey(),StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);changed.add(e.getKey());}
  }catch(IOException e){Collections.reverse(changed);for(Path dest:changed)try{if(existed.contains(dest))Files.copy(backup.resolve(root.relativize(dest)),dest,StandardCopyOption.REPLACE_EXISTING);else Files.deleteIfExists(dest);}catch(IOException restore){e.addSuppressed(restore);}throw e;}finally{for(Path tmp:staged.values())Files.deleteIfExists(tmp);}
 }
 Path backup(String action){return plugin.getDataFolder().toPath().resolve("web-backups").resolve(action+"-"+System.currentTimeMillis()+"-"+UUID.randomUUID());}
 void say(CommandSender s,String message){s.sendMessage("[Nodes Web] "+message);}
 public boolean command(CommandSender s,String[] args)throws Exception{
  if(!s.hasPermission("nodes.admin"))throw new IllegalArgumentException("nodes.admin permission required.");
  if(args.length!=2){say(s,"/nda dynmap install | export | status | links");return true;}
  String sub=args[1].toLowerCase(Locale.ROOT);if(sub.equals("links")){String base=plugin.getConfig().getString("nodesWeb.publicUrl","").replaceAll("/+$","");say(s,base.isBlank()?"Set nodesWeb.publicUrl to your public Dynmap URL. Pages: /nodes.html and /editor.html":base+"/nodes.html  |  "+base+"/editor.html");return true;}
  Path root=root();Map<String,byte[]> files=bundle();
  switch(sub){
   case "install"->{Path backup=backup("install");deploy(root,backup,files);say(s,"Installed "+files.size()+" editor/viewer assets. Backup: "+backup);say(s,"Next: /nda dynmap export, then /nda dynmap links. Existing Dynmap index and server configuration are preserved.");}
   case "export"->{Map<String,byte[]> data=new LinkedHashMap<>();for(String name:List.of("world.json","towns.json","config.json","ports.json","nameoverrides.json")){Path source=plugin.getDataFolder().toPath().resolve(name);if(Files.isRegularFile(source))data.put("nodes/"+name,Files.readAllBytes(source));}for(String required:List.of("world.json","towns.json","config.json"))if(!data.containsKey("nodes/"+required))throw new IllegalArgumentException("Missing Nodes "+required+". Save/export native Nodes data first.");Path backup=backup("export");deploy(root,backup,data);say(s,"Exported "+data.size()+" existing JSON files. Backup: "+backup);say(s,"This copies the last saved JSON snapshot. Use /nda save sync before export for current native town data.");}
   case "status"->{int absent=0,changed=0;for(var e:files.entrySet()){Path f=safe(root,e.getKey());if(!Files.isRegularFile(f))absent++;else if(!Arrays.equals(Files.readAllBytes(f),e.getValue()))changed++;}say(s,"Web root: "+root+"; missing assets="+absent+"; changed assets="+changed);for(String name:List.of("world.json","towns.json","config.json"))say(s,name+": "+(Files.isRegularFile(root.resolve("nodes/"+name))?"present":"missing"));}
   default->throw new IllegalArgumentException("Use install, export, status or links.");
  }return true;
 }
}
