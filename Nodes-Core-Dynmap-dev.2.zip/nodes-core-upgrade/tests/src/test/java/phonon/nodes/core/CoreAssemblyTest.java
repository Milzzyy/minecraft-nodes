package phonon.nodes.core;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.*;
import java.util.jar.*;
import static org.junit.jupiter.api.Assertions.*;
class CoreAssemblyTest {
 @TempDir Path folder;
 @Test void samePluginCoreHooksAreEmbeddedAndBytecodeIsStructurallyValid()throws Exception{
  Path output=folder.resolve("nodes.jar");CoreAssembler.main(new String[]{"packaging/base-nodes.jar","target/classes","MainNodes/nodes/src/main/resources",output.toString()});
  try(JarFile jar=new JarFile(output.toFile())){
   String descriptor=new String(jar.getInputStream(jar.getJarEntry("plugin.yml")).readAllBytes(),java.nio.charset.StandardCharsets.UTF_8);
   assertTrue(descriptor.contains("name: nodes"));assertTrue(descriptor.contains("main: phonon.nodes.NodesPlugin"));
   assertNotNull(jar.getEntry("phonon/nodes/core/Politics.class"));assertNotNull(jar.getEntry("phonon/nodes/core/CoreFeatures.class"));
   assertNull(jar.getEntry("london/nodesbounties/NodesBounties.class"));assertTrue(CoreAssembler.applied.get("income")>0);assertTrue(CoreAssembler.applied.get("canJoin")>0);
  }
 }
}
