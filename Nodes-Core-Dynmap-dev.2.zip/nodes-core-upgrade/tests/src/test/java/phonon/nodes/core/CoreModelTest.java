package phonon.nodes.core;
import org.junit.jupiter.api.Test;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
class CoreModelTest {
 @Test void durationFormats(){assertEquals(172800000,TimeValue.millis("2d"));assertEquals(5400000,TimeValue.millis("1h30m"));assertEquals(1500,TimeValue.millis("1.5s"));assertEquals(1000,TimeValue.millis(1000L));}
 @Test void invalidDurationCannotDisableCooldownSilently(){for(Object input:List.of("2x","1h bad","-1",-1L,"9999999999999999999d"))assertThrows(RuntimeException.class,()->TimeValue.millis(input));}
 @Test void rejectsCyclesAndDuplicateOverlords(){UUID a=UUID.randomUUID(),b=UUID.randomUUID(),d=UUID.randomUUID();SubjectGraph g=new SubjectGraph();g.add(new SubjectGraph.Link(a,b,SubjectGraph.Kind.VASSAL,10,10,0));assertThrows(IllegalArgumentException.class,()->g.add(new SubjectGraph.Link(b,a,SubjectGraph.Kind.VASSAL,10,10,0)));assertThrows(IllegalArgumentException.class,()->g.add(new SubjectGraph.Link(a,d,SubjectGraph.Kind.TRIBUTARY,10,10,0)));}
 @Test void vassalWarTreeExcludesIndependentTributaries(){UUID a=UUID.randomUUID(),b=UUID.randomUUID(),d=UUID.randomUUID();SubjectGraph g=new SubjectGraph();g.add(new SubjectGraph.Link(b,a,SubjectGraph.Kind.VASSAL,0,0,0));g.add(new SubjectGraph.Link(d,a,SubjectGraph.Kind.TRIBUTARY,0,0,0));assertEquals(Set.of(b),g.vassalTree(a));}
 @Test void timedConquestExpires(){UUID a=UUID.randomUUID(),b=UUID.randomUUID();SubjectGraph g=new SubjectGraph();g.add(new SubjectGraph.Link(b,a,SubjectGraph.Kind.CONQUERED,0,0,100));g.expire(99);assertEquals(1,g.links.size());g.expire(100);assertTrue(g.links.isEmpty());}
 @Test void taxCapsAndDistancePenalty(){assertEquals(.3,SubjectGraph.effectiveRate(50,30,96,96,.01),1e-8);assertEquals(.15,SubjectGraph.effectiveRate(50,30,146,96,.01),1e-8);assertEquals(0,SubjectGraph.effectiveRate(50,30,300,96,.01));}
 @Test void rejectsNonFiniteTax(){assertThrows(IllegalArgumentException.class,()->new SubjectGraph.Link(UUID.randomUUID(),UUID.randomUUID(),SubjectGraph.Kind.VASSAL,Double.NaN,0,0));assertThrows(IllegalArgumentException.class,()->Politics.percent("Infinity"));}
 @Test void moneyUsesExactWholeCents(){assertEquals(12345,CoreEconomy.cents("123.45"));assertThrows(IllegalArgumentException.class,()->CoreEconomy.cents("1.001"));assertThrows(IllegalArgumentException.class,()->CoreEconomy.cents("-1"));}
}
