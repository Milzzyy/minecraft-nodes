package phonon.nodes.core;

import org.objectweb.asm.*;
import org.objectweb.asm.util.CheckClassAdapter;
import java.nio.file.*;
import java.util.*;
import java.util.jar.*;
import java.io.*;

/** Reproducible assembly against the supplied built fork; no replacement plugin or second lifecycle. */
public final class CoreAssembler {
    static final String H="phonon/nodes/core/CoreHooks";static final Map<String,Integer> applied=new TreeMap<>();
    static void hit(String key){applied.merge(key,1,Integer::sum);}
    static void hook(MethodVisitor m,String name,String descriptor){m.visitMethodInsn(Opcodes.INVOKESTATIC,H,name,descriptor,false);hit(name);}
    static byte[] patch(String path,byte[] input){
        ClassReader reader=new ClassReader(input);
        Set<String> existing=new HashSet<>();reader.accept(new ClassVisitor(Opcodes.ASM9){@Override public MethodVisitor visitMethod(int a,String n,String d,String sig,String[] ex){return new MethodVisitor(Opcodes.ASM9){@Override public void visitMethodInsn(int op,String owner,String method,String descriptor,boolean itf){if(owner.equals(H))existing.add(method);}};}},ClassReader.SKIP_DEBUG|ClassReader.SKIP_FRAMES);
        if(!existing.isEmpty()){for(String method:existing)hit(method);return input;}
        ClassWriter writer=new ClassWriter(ClassWriter.COMPUTE_MAXS);String owner=reader.getClassName();
        reader.accept(new ClassVisitor(Opcodes.ASM9,writer){
            @Override public MethodVisitor visitMethod(int access,String name,String desc,String signature,String[] exceptions){
                MethodVisitor target=super.visitMethod(access,name,desc,signature,exceptions);
                return new MethodVisitor(Opcodes.ASM9,target){
                    boolean guard=false;
                    void frame(){List<Object> locals=new ArrayList<>();if((access&Opcodes.ACC_STATIC)==0)locals.add(owner);for(Type t:Type.getArgumentTypes(desc))locals.add(switch(t.getSort()){case Type.BOOLEAN,Type.BYTE,Type.CHAR,Type.SHORT,Type.INT->Opcodes.INTEGER;case Type.LONG->Opcodes.LONG;case Type.FLOAT->Opcodes.FLOAT;case Type.DOUBLE->Opcodes.DOUBLE;case Type.ARRAY->t.getDescriptor();default->t.getInternalName();});mv.visitFrame(Opcodes.F_NEW,locals.size(),locals.toArray(),0,new Object[0]);}
                    void allow(String method,String descriptor,Runnable arguments){arguments.run();hook(mv,method,descriptor);Label allowed=new Label();mv.visitJumpInsn(Opcodes.IFNE,allowed);mv.visitInsn(Opcodes.RETURN);mv.visitLabel(allowed);frame();}
                    @Override public void visitCode(){super.visitCode();
                        if((owner.equals("phonon/nodes/listeners/NodesWorldListener")||owner.equals("phonon/nodes/listeners/NodesBlockGrowListener")||owner.equals("phonon/nodes/listeners/NodesEntityBreedListener")||owner.equals("phonon/nodes/listeners/NodesSheepShearListener")||owner.equals("phonon/nodes/listeners/NodesPlayerDamageListener"))&&name.startsWith("on")&&!name.equals("onPlayerQuit")&&Type.getArgumentTypes(desc).length==1&&desc.endsWith(")V"))allow(owner.endsWith("NodesWorldListener")&&Set.of("onBlockBreak","onBlockPlace","onBlockInteract","onEntityInteract","onPlayerBucketEmpty").contains(name)?"interaction":"worldEvent","(Lorg/bukkit/event/Event;)Z",()->mv.visitVarInsn(Opcodes.ALOAD,1));
                        if(owner.equals("phonon/nodes/war/FlagWar")&&name.startsWith("canAttackFromNeighborChunk")&&!name.contains("Warzone")){mv.visitVarInsn(Opcodes.ALOAD,1);hook(mv,"border","(Ljava/lang/Object;)Z");Label allowed=new Label();mv.visitJumpInsn(Opcodes.IFNE,allowed);mv.visitInsn(Opcodes.ICONST_0);mv.visitInsn(Opcodes.IRETURN);mv.visitLabel(allowed);frame();}
                        if(owner.equals("phonon/nodes/Config")&&name.equals("load")&&desc.equals("(Lorg/bukkit/configuration/file/FileConfiguration;)V")){mv.visitVarInsn(Opcodes.ALOAD,1);hook(mv,"prepare","(Lorg/bukkit/configuration/file/FileConfiguration;)V");}
                        if(owner.equals("phonon/nodes/NodesPlugin")&&name.equals("onDisable"))hook(mv,"disable","()V");
                        if(owner.equals("phonon/nodes/objects/IncomeInventory")&&name.equals("add")&&desc.equals("(Lorg/bukkit/Material;II)V")){mv.visitVarInsn(Opcodes.ALOAD,0);mv.visitVarInsn(Opcodes.ALOAD,1);mv.visitVarInsn(Opcodes.ILOAD,2);hook(mv,"income","(Ljava/lang/Object;Lorg/bukkit/Material;I)I");mv.visitVarInsn(Opcodes.ISTORE,2);}
                        if(owner.equals("phonon/nodes/listeners/NodesWorldListenerKt")&&name.equals("handleHiddenOre"))allow("hiddenOre","(Lorg/bukkit/entity/Player;Lorg/bukkit/block/Block;)Z",()->{mv.visitVarInsn(Opcodes.ALOAD,0);mv.visitVarInsn(Opcodes.ALOAD,1);});
                        if(owner.equals("phonon/nodes/war/AttackTextDisplay")&&name.equals("respawn"))allow("respawn","()Z",()->{});
                        if(owner.equals("phonon/nodes/placeholders/NodesExpansion")&&name.equals("onPlaceholderRequest")){hook(mv,"papi","()Z");Label enabled=new Label();mv.visitJumpInsn(Opcodes.IFNE,enabled);mv.visitInsn(Opcodes.ACONST_NULL);mv.visitInsn(Opcodes.ARETURN);mv.visitLabel(enabled);frame();}
                        if(owner.equals("phonon/nodes/listeners/NodesBlockGrowListener")&&name.equals("onBlockGrow"))allow("crops","()Z",()->{});
                        if(owner.equals("phonon/nodes/listeners/NodesChatListener")&&name.equals("onPlayerChat"))allow("chat","()Z",()->{});
                        if(owner.equals("phonon/nodes/objects/Nametag")&&(name.startsWith("refresh")||name.equals("updateTextForPlayer"))&&desc.endsWith(")V"))allow("nametags","()Z",()->{});
                        if(owner.equals("phonon/nodes/Nodes")&&name.equals("addResidentToTown"))allow("canJoin","(Ljava/lang/Object;Ljava/lang/Object;)Z",()->{mv.visitVarInsn(Opcodes.ALOAD,2);mv.visitVarInsn(Opcodes.ALOAD,1);});
                        if(owner.equals("phonon/nodes/Nodes")&&name.equals("removeResidentFromTown")){mv.visitVarInsn(Opcodes.ALOAD,1);mv.visitVarInsn(Opcodes.ALOAD,2);hook(mv,"left","(Ljava/lang/Object;Ljava/lang/Object;)V");}
                        if(owner.equals("phonon/nodes/war/FlagWar")&&name.startsWith("attackTick")){mv.visitVarInsn(Opcodes.ALOAD,1);hook(mv,"accelerate","(Ljava/lang/Object;)V");}
                    }
                    @Override public void visitMethodInsn(int opcode,String targetOwner,String method,String descriptor,boolean itf){
                        if(targetOwner.equals("org/bukkit/inventory/meta/SkullMeta")&&method.equals("setOwningPlayer")&&descriptor.equals("(Lorg/bukkit/OfflinePlayer;)Z")){hook(mv,"skull","(Lorg/bukkit/inventory/meta/SkullMeta;Lorg/bukkit/OfflinePlayer;)Z");return;}
                        if(targetOwner.equals("org/bukkit/inventory/meta/SkullMeta")&&method.equals("setOwnerProfile")&&descriptor.equals("(Lorg/bukkit/profile/PlayerProfile;)V")){hook(mv,"skullProfile","(Lorg/bukkit/inventory/meta/SkullMeta;Lorg/bukkit/profile/PlayerProfile;)V");return;}
                        super.visitMethodInsn(opcode,targetOwner,method,descriptor,itf);
                    }
                    @Override public void visitInsn(int opcode){
                        if(opcode==Opcodes.LRETURN&&owner.equals("phonon/nodes/war/FlagWar")&&name.equals("computeChunkAttackTimeTicks")){
                            mv.visitVarInsn(Opcodes.ALOAD,1);mv.visitInsn(Opcodes.DUP_X2);mv.visitInsn(Opcodes.POP);mv.visitVarInsn(Opcodes.ALOAD,2);mv.visitInsn(Opcodes.DUP_X2);mv.visitInsn(Opcodes.POP);hook(mv,"attackTime","(Ljava/lang/Object;Ljava/lang/Object;J)J");
                        }
                        if(opcode==Opcodes.RETURN){
                            if(owner.equals("phonon/nodes/NodesPlugin")&&name.equals("onEnable")){mv.visitVarInsn(Opcodes.ALOAD,0);hook(mv,"enable","(Lorg/bukkit/plugin/java/JavaPlugin;)V");}
                            if(owner.equals("phonon/nodes/objects/Nation")&&name.equals("printInfo")){mv.visitVarInsn(Opcodes.ALOAD,1);mv.visitVarInsn(Opcodes.ALOAD,0);hook(mv,"socialInfo","(Lorg/bukkit/command/CommandSender;Ljava/lang/Object;)V");}
                            if(owner.equals("phonon/nodes/objects/Minimap")&&name.equals("render")){mv.visitVarInsn(Opcodes.ALOAD,0);hook(mv,"minimap","(Ljava/lang/Object;)V");}
                        }super.visitInsn(opcode);
                    }
                };
            }
        },ClassReader.EXPAND_FRAMES);
        byte[] output=writer.toByteArray();new ClassReader(output).accept(new CheckClassAdapter(new ClassWriter(0),true),0);return output;
    }
    public static void main(String[] args)throws Exception{
        if(args.length<4)throw new IllegalArgumentException("base.jar classes resources output.jar [runtime dependency jars...]");
        Map<String,byte[]> files=new LinkedHashMap<>();try(JarFile base=new JarFile(args[0])){var e=base.entries();while(e.hasMoreElements()){var entry=e.nextElement();if(!entry.isDirectory()&&!entry.getName().matches("META-INF/.*\\.(SF|RSA|DSA)"))files.put(entry.getName(),base.getInputStream(entry).readAllBytes());}}
        Set<String> patched=Set.of("phonon/nodes/Config.class","phonon/nodes/NodesPlugin.class","phonon/nodes/objects/IncomeInventory.class","phonon/nodes/listeners/NodesWorldListenerKt.class","phonon/nodes/listeners/NodesBlockGrowListener.class","phonon/nodes/listeners/NodesChatListener.class","phonon/nodes/objects/Nametag.class","phonon/nodes/Nodes.class","phonon/nodes/objects/Nation.class","phonon/nodes/objects/Minimap.class","phonon/nodes/war/FlagWar.class");
        Set<String> allPatched=new HashSet<>(patched);allPatched.add("phonon/nodes/listeners/NodesWorldListener.class");allPatched.add("phonon/nodes/war/AttackTextDisplay.class");allPatched.add("phonon/nodes/placeholders/NodesExpansion.class");allPatched.add("phonon/nodes/listeners/NodesEntityBreedListener.class");allPatched.add("phonon/nodes/listeners/NodesSheepShearListener.class");allPatched.add("phonon/nodes/listeners/NodesPlayerDamageListener.class");
        for(String path:allPatched){if(!files.containsKey(path))throw new IllegalStateException("Required original class missing: "+path);files.put(path,patch(path,files.get(path)));}
        for(String required:List.of("enable","disable","prepare","income","hiddenOre","crops","chat","nametags","canJoin","left","socialInfo","minimap","accelerate","interaction","worldEvent"))if(!applied.containsKey(required))throw new IllegalStateException("Missing integration hook: "+required);
        for(int i=4;i<args.length;i++)try(JarFile dependency=new JarFile(args[i])){var e=dependency.entries();while(e.hasMoreElements()){var entry=e.nextElement();String name=entry.getName();if(entry.isDirectory()||name.equals("META-INF/MANIFEST.MF")||name.endsWith("module-info.class")||name.matches("META-INF/.*\\.(SF|RSA|DSA)"))continue;if(name.equals("META-INF/services/java.sql.Driver")&&files.containsKey(name)){files.put(name,(new String(files.get(name),java.nio.charset.StandardCharsets.UTF_8)+"\n"+new String(dependency.getInputStream(entry).readAllBytes(),java.nio.charset.StandardCharsets.UTF_8)).getBytes(java.nio.charset.StandardCharsets.UTF_8));}else files.putIfAbsent(name,dependency.getInputStream(entry).readAllBytes());}}
        for(String directory:List.of(args[1],args[2]))try(var walk=Files.walk(Path.of(directory))){for(Path p:walk.filter(Files::isRegularFile).toList()){String path=Path.of(directory).relativize(p).toString().replace('\\','/');if(directory.equals(args[1])&&!path.startsWith("phonon/nodes/core/"))continue;files.put(path,Files.readAllBytes(p));}}
        Path output=Path.of(args[3]);Files.createDirectories(output.toAbsolutePath().getParent());try(var jar=new JarOutputStream(Files.newOutputStream(output))){for(var file:files.entrySet()){jar.putNextEntry(new JarEntry(file.getKey()));jar.write(file.getValue());jar.closeEntry();}}
        System.out.println("Core integration hooks: "+applied);System.out.println("Assembled "+output+" with "+files.size()+" entries");
    }
}
